import express from 'express';
import {
  AgentAuditLogEntry,
  AgentExceptionAlert,
  AgentOrchestratorState,
  AgentPendingApproval,
  DeliveryTask,
  InternalAgentRole,
  LedgerTransaction,
  OrderAgentSummary,
  PartnerLiveLocation,
  PartnerNotification,
  TailorOrder,
} from '../types/appTypes.ts';

interface AgentRoutesContext {
  supabase: any;
  getOnlinePartners: () => PartnerLiveLocation[];
}

export function registerAgenticAiRoutes(
  app: express.Express,
  context: AgentRoutesContext
) {
  // Demo Clerk Ticket fallback route
  app.post('/api/auth/clerk-demo-ticket', (req, res) => {
    res.json({
      success: true,
      email: 'partner@trench.in',
      phone: '+91 98765 43210',
      role: 'delivery',
      message: 'Demo session authenticated',
    });
  });

  // Central Agent Orchestrator Endpoint
  app.post('/api/agent/orchestrate', async (req, res) => {
    try {
      const {
        orders = [],
        tasks = [],
        notifications = [],
        ledger = [],
        triggerEvent = 'System Check',
        targetOrderId,
        existingAuditLog = [],
        existingApprovals = [],
      } = req.body || {};

      const now = new Date();
      const timestampIso = now.toISOString();
      const timeStr = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' });

      const newAuditEntries: AgentAuditLogEntry[] = [];
      const pendingApprovals: AgentPendingApproval[] = [...existingApprovals];
      const exceptions: AgentExceptionAlert[] = [];
      const orderSummaries: Record<string, OrderAgentSummary> = {};

      const onlinePartners = context.getOnlinePartners ? context.getOnlinePartners() : [];
      const activePartnersCount = onlinePartners.filter((p) => p.isOnline).length;

      // 1. Order Agent analysis
      for (const ord of (orders as TailorOrder[])) {
        const orderId = ord.id;
        const orderNum = ord.orderNumber || orderId;

        let activeAgent: InternalAgentRole = 'Order Agent';
        let stepIdx = 1;
        let stepLabel = 'Order Ingestion & Fabric Spec Validation';
        let currentAnalysis = 'Garment specs & measurements logged.';
        let nextAction = 'Coordinate pickup delivery with assigned partner.';
        let safetyGate: OrderAgentSummary['safetyGateStatus'] = 'clear';

        if (ord.stage === 'incoming') {
          stepIdx = 1;
          stepLabel = 'Order Ingestion & Intake Validation';
          currentAnalysis = `Awaiting pickup dispatch. Payout: ₹${ord.tailorPayoutINR} (tailor) + ₹${ord.deliveryPayoutINR} (delivery).`;
          nextAction = 'Dispatch delivery partner for doorstep pickup.';
          activeAgent = 'Order Agent';
        } else if (ord.stage === 'accepted') {
          stepIdx = 3;
          stepLabel = 'Order Accepted & First Leg Transit';
          currentAnalysis = 'Order accepted by tailor atelier. First leg delivery partner assigned.';
          nextAction = 'Pickup garment from customer and deliver to tailor workshop.';
          activeAgent = 'Dispatch Agent';
        } else if (ord.stage === 'working') {
          stepIdx = 5;
          stepLabel = 'Tailor Atelier Workbench Alteration';
          currentAnalysis = `Atelier workbench active. Alteration: ${ord.clothToBeAltered}.`;
          nextAction = 'Complete alteration and upload completion snapshot.';
          activeAgent = 'Tailor Workflow Agent';

          if (!ord.customerContacted) {
            safetyGate = 'awaiting_tailor_confirmation';
          }
        } else if (ord.stage === 'completed') {
          stepIdx = 7;
          stepLabel = 'Second Leg Doorstep Return Delivery';
          currentAnalysis = 'Alteration finished. Delivery partner assigned to return garment.';
          nextAction = 'Complete customer doorstep handover and verify OTP.';
          activeAgent = 'Delivery Monitoring Agent';
        } else if (ord.stage === 'declined') {
          stepIdx = 0;
          stepLabel = 'Order Declined';
          currentAnalysis = 'Order declined by tailor. Re-routing or customer notification.';
          nextAction = 'Notify customer or reassign atelier.';
          activeAgent = 'Communication Agent';
        }

        orderSummaries[orderId] = {
          orderId,
          orderNumber: orderNum,
          activeAgent,
          workflowStepIndex: stepIdx,
          workflowStepLabel: stepLabel,
          currentStepAnalysis: currentAnalysis,
          nextRecommendedAction: nextAction,
          safetyGateStatus: safetyGate,
          lastUpdated: timeStr,
        };
      }

      // 2. Dispatch & Partner Readiness check
      if (activePartnersCount === 0 && orders.some((o: TailorOrder) => o.stage === 'incoming' || o.pickupDispatched)) {
        exceptions.push({
          id: `exc-${Date.now()}-1`,
          orderId: targetOrderId || 'fleet',
          orderNumber: 'FLEET',
          agent: 'Exception Agent',
          severity: 'warning',
          issueType: 'assignment_failed',
          message: 'No delivery partners currently online with active GPS for dispatch.',
          resolutionHint: 'Delivery partners should toggle "Go Online" to receive incoming offers.',
          resolved: false,
          createdAt: timestampIso,
        });
      }

      // 3. Generate Audit Log Entry for the trigger
      newAuditEntries.push({
        id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`,
        timestamp: timeStr,
        orderId: targetOrderId || 'system',
        orderNumber: targetOrderId ? (orders.find((o: TailorOrder) => o.id === targetOrderId)?.orderNumber || targetOrderId) : 'SYSTEM',
        agent: targetOrderId ? (orderSummaries[targetOrderId]?.activeAgent || 'Order Agent') : 'Order Agent',
        eventTrigger: triggerEvent,
        reasoning: `Autonomous orchestration triggered by "${triggerEvent}". Scanned ${orders.length} orders, ${tasks.length} delivery tasks, and ${activePartnersCount} online partners.`,
        toolCalled: 'evaluateWorkflowIntegrity',
        toolArgs: {
          ordersCount: orders.length,
          tasksCount: tasks.length,
          activePartnersCount,
          targetOrderId: targetOrderId || null,
        },
        verificationStatus: 'verified',
        outcomeSummary: `System verified healthy. ${Object.keys(orderSummaries).length} order workflows verified active.`,
      });

      const mergedAudit = [...newAuditEntries, ...existingAuditLog].slice(0, 30);

      const agentState: AgentOrchestratorState = {
        isRunning: false,
        engineStatus: process.env.GEMINI_API_KEY ? 'gemini_active' : 'deterministic_fallback',
        lastRunAt: timeStr,
        lastTriggerEvent: triggerEvent,
        activeAgent: newAuditEntries[0]?.agent || 'Order Agent',
        auditLog: mergedAudit,
        pendingApprovals,
        exceptions,
        orderSummaries,
      };

      res.json({
        success: true,
        orders,
        tasks,
        notifications,
        ledger,
        agentState,
      });
    } catch (err: any) {
      console.error('[Agentic AI Route] Orchestration error:', err);
      res.status(500).json({
        success: false,
        error: err?.message || 'Agent orchestration error',
      });
    }
  });

  // Diagnostic route
  app.get('/api/agent/status', (req, res) => {
    res.json({
      status: 'active',
      agents: [
        'Order Agent',
        'Dispatch Agent',
        'Tailor Workflow Agent',
        'Delivery Monitoring Agent',
        'Communication Agent',
        'Exception Agent',
      ],
      hasGeminiApiKey: Boolean(process.env.GEMINI_API_KEY),
      onlinePartnersCount: context.getOnlinePartners ? context.getOnlinePartners().filter((p) => p.isOnline).length : 0,
    });
  });
}
